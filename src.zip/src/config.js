export default {
  jwtSecret: 'somesecretkeyforjsonwebtoken'
}